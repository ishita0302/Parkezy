package com.parkezy.parkezy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkezyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkezyApplication.class, args);
	}

}
