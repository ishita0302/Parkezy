package com.parking.space.parkingspace;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkingspaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingspaceApplication.class, args);
	}

}
