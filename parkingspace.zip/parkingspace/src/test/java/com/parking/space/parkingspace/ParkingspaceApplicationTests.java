package com.parking.space.parkingspace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingspaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
